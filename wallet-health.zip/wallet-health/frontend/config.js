// Change these after you deploy (see README)
const CONFIG = {
  BACKEND_URL: "http://localhost:5000",
  CONTRACT_ADDRESS: "PASTE_YOUR_CONTRACT_ADDRESS",
  CHAIN_ID: 11155111,                       // Ethereum Sepolia
  EXPLORER: "https://sepolia.etherscan.io",
};
