# Wallet Health Score (Innoblock 2.0, PS 16)
AI-assisted tool that scores a wallet 0-100 on security habits, shows which factors lowered it, and ranks fixes by points gained. The score and a SHA-256 hash of the full report are stored on a testnet, so history is public and tamper-proof.

## Why blockchain
Reports live off-chain; only `wallet, score, reportHash, time` go on-chain. Anyone can re-hash a report and verify it was never edited, and the contract's events are the score history.

## Scoring (weights sum to 100)
| Factor | Max | Deductions |
|---|---|---|
| approvals | 30 | -5 per unlimited, -2 per stale approval |
| contracts | 25 | -7 per flagged, -3 per unverified contract |
| spread | 20 | scales down as one asset/wallet holds more of the value |
| activity | 15 | -2 per unknown dust token |
| hygiene | 10 | +5 multisig/ENS, +5 has revoked approvals before |

Frontend extras: grade and verdict, comparison with the sample average, fix simulator (tick fixes to see the projected score), on-chain score history chart, report download and hash copy, custom address input.

Demo results: risky wallet 5, clean wallet 100, risky after fixes 65.

## Setup
1. Deploy `contracts/WalletScoreRegistry.sol` in Remix (MetaMask, Sepolia), verify it on sepolia.etherscan.io.
2. Backend: `cd backend && pip install -r requirements.txt && python app.py` (check localhost:5000/health). Optional: set `ANTHROPIC_API_KEY` for AI-worded recommendations.
3. Frontend: put the contract address in `frontend/config.js`, then `cd frontend && python -m http.server 8000` and open localhost:8000.

## Test
Score "Risky sample wallet" -> Save score on-chain -> Verify -> "Change 1 character" (fails) -> score "Risky wallet after fixes" and save again.

## Notes
Sample wallets use built-in data so the demo is repeatable. Real data: implement `fetch_wallet_data()` in `backend/app.py` with Etherscan/Alchemy. Use burner wallets and testnets only. Never commit `.env`.

Team: (add names) · Contract: (add address)
