"""Wallet Health backend: scores a wallet 0-100, ranks fixes, hashes the report.
Run: pip install -r requirements.txt && python app.py   (then open /health)
Demo wallets use sample data so the demo is repeatable; see fetch_wallet_data()
to plug in real Etherscan/Alchemy data."""
import hashlib, json, os
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins=os.getenv("FRONTEND_ORIGIN", "*"))

# ---- Documented weights (sum = 100) ----
WEIGHTS = {"approvals": 30, "contracts": 25, "spread": 20, "activity": 15, "hygiene": 10}

SAMPLES = {
    "risky": {"address": "0x1111111111111111111111111111111111111111",
              "unlimited_approvals": 5, "stale_approvals": 4, "flagged_contracts": 3,
              "unverified_contracts": 2, "top_asset_share": 0.93, "dust_tokens": 6,
              "uses_multisig_or_ens": False, "revoked_before": False},
    "clean": {"address": "0x2222222222222222222222222222222222222222",
              "unlimited_approvals": 0, "stale_approvals": 0, "flagged_contracts": 0,
              "unverified_contracts": 0, "top_asset_share": 0.40, "dust_tokens": 0,
              "uses_multisig_or_ens": True, "revoked_before": True},
}
# the risky wallet after following the top recommendations ("score rises" demo)
SAMPLES["risky_fixed"] = {**SAMPLES["risky"], "address": "0x1111111111111111111111111111111111111111",
                          "unlimited_approvals": 0, "stale_approvals": 0,
                          "dust_tokens": 0, "top_asset_share": 0.55, "revoked_before": True}


def fetch_wallet_data(address):
    """Return wallet facts. Demo: sample data. Real: call Etherscan/Alchemy here."""
    key = address.lower()
    if key in SAMPLES:
        return SAMPLES[key]
    for name in ("risky", "clean"):
        if key == SAMPLES[name]["address"]:
            return SAMPLES[name]
    # Unknown address: neutral placeholder so the UI still works
    return {**SAMPLES["clean"], "address": address, "unlimited_approvals": 1, "top_asset_share": 0.7}


def score_wallet(d):
    f = {}
    f["approvals"] = (max(0, 30 - 5 * d["unlimited_approvals"] - 2 * d["stale_approvals"]),
        f'{d["unlimited_approvals"]} unlimited and {d["stale_approvals"]} stale approvals')
    f["contracts"] = (max(0, 25 - 7 * d["flagged_contracts"] - 3 * d["unverified_contracts"]),
        f'{d["flagged_contracts"]} flagged and {d["unverified_contracts"]} unverified contracts used')
    f["spread"] = (round(20 * min(1, max(0, (1 - d["top_asset_share"]) / 0.6))),
        f'{int(d["top_asset_share"]*100)}% of value sits in one asset/wallet')
    f["activity"] = (max(0, 15 - 2 * d["dust_tokens"]),
        f'{d["dust_tokens"]} unknown dust tokens received')
    f["hygiene"] = ((5 if d["uses_multisig_or_ens"] else 0) + (5 if d["revoked_before"] else 0),
        f'multisig/ENS: {d["uses_multisig_or_ens"]}, revoked approvals before: {d["revoked_before"]}')
    breakdown = [{"factor": k, "points": p, "max": WEIGHTS[k], "lost": WEIGHTS[k] - p, "evidence": e}
                 for k, (p, e) in f.items()]
    return sum(b["points"] for b in breakdown), breakdown


FIXES = {
    "approvals": "Revoke unlimited and stale token approvals (e.g. on revoke.cash) and re-approve exact amounts only.",
    "contracts": "Stop using flagged or unverified contracts; check any contract on the explorer first.",
    "spread": "Move savings to a separate cold or multisig wallet; keep only spending money here.",
    "activity": "Never approve unknown dust tokens; hide them in your wallet.",
    "hygiene": "Set up a multisig or ENS name and review approvals regularly.",
}


def recommend(breakdown):
    recs = [{"factor": b["factor"], "action": FIXES[b["factor"]], "gain": b["lost"]}
            for b in breakdown if b["lost"] > 0]
    recs.sort(key=lambda r: r["gain"], reverse=True)  # ranked by points gained
    key = os.getenv("ANTHROPIC_API_KEY")
    if key and recs:  # optional AI step: plainer wording of the same ranked fixes
        try:
            import requests
            r = requests.post("https://api.anthropic.com/v1/messages", timeout=30,
                headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
                json={"model": os.getenv("AI_MODEL", "claude-sonnet-4-5"), "max_tokens": 400,
                      "messages": [{"role": "user", "content":
                      "Rewrite each action as one short friendly sentence for a beginner. "
                      "Return only a JSON list of strings, same order.\n"
                      + json.dumps([x["action"] for x in recs])}]})
            for x, t in zip(recs, json.loads(r.json()["content"][0]["text"])): x["action"] = t
        except Exception:
            pass  # fall back to built-in wording
    return recs


@app.get("/health")
def health():
    return jsonify(ok=True)


@app.get("/score/<address>")
def score(address):
    d = fetch_wallet_data(address)
    total, breakdown = score_wallet(d)
    report = {"address": d["address"], "score": total, "breakdown": breakdown,
              "recommendations": recommend(breakdown)}
    canon = json.dumps(report, sort_keys=True, separators=(",", ":"))
    return jsonify({**report, "canonical_report": canon,
                    "report_hash": "0x" + hashlib.sha256(canon.encode()).hexdigest()})


@app.post("/hash")
def hash_text():
    """Re-hash report text so the page can verify it against the chain."""
    return jsonify(hash="0x" + hashlib.sha256(request.json["text"].encode()).hexdigest())


@app.get("/benchmark")
def benchmark():
    s = [score_wallet(SAMPLES[k])[0] for k in ("risky", "clean")]
    return jsonify(average=sum(s) / len(s))


if __name__ == "__main__":
    app.run(port=5000, debug=True)
