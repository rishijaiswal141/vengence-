// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title WalletScoreRegistry
/// @notice Stores a wallet's security score and the SHA-256 hash of its full report.
///         The full report lives off-chain; anyone can re-hash it and compare.
contract WalletScoreRegistry {
    struct Entry { address wallet; uint8 score; bytes32 reportHash; uint256 time; }

    event ScoreStored(uint256 indexed id, address indexed wallet, uint8 score, bytes32 reportHash, uint256 time);

    mapping(uint256 => Entry) public entries;      // id => entry (ids start at 1)
    mapping(address => uint256[]) private history; // wallet => its entry ids
    uint256 public count;

    /// Save a score + report hash. Score history = the ids stored for a wallet.
    function store(address wallet, uint8 score, bytes32 reportHash) external returns (uint256 id) {
        require(score <= 100, "score must be 0-100");
        id = ++count;
        entries[id] = Entry(wallet, score, reportHash, block.timestamp);
        history[wallet].push(id);
        emit ScoreStored(id, wallet, score, reportHash, block.timestamp);
    }

    /// Does this hash match the one stored under id? (free to call)
    function verify(uint256 id, bytes32 reportHash) external view returns (bool) {
        return entries[id].reportHash == reportHash;
    }

    /// All entry ids for a wallet, oldest first (for the score-history view).
    function historyOf(address wallet) external view returns (uint256[] memory) {
        return history[wallet];
    }
}
